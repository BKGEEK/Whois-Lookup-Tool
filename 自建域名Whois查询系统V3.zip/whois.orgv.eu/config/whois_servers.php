<?php
return [
    'com'    => 'whois.verisign-grs.com',
    'net'    => 'whois.verisign-grs.com',
    'org'    => 'whois.pir.org',
    'info'   => 'whois.afilias.net',
    'cn'     => 'whois.cnnic.cn',
    'edu.cn' => 'whois.edu.cn',
    'hk'     => 'whois.hkirc.hk',
    'tw'     => 'whois.twnic.net.tw',
    'ai'     => 'whois.nic.ai',
    'io'     => 'whois.nic.io',
    'xyz'    => 'whois.nic.xyz',
    'pp.ua'  => 'whois.ua',
    // 可继续扩展
];
